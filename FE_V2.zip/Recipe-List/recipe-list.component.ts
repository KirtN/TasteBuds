import { Component } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { MatListModule } from '@angular/material/list';  
import { MatIconModule } from '@angular/material/icon';





@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.scss'],
  standalone: true, // This makes the component standalone
  imports: [CommonModule, MatListModule, MatIconModule] 
})
export class RecipeListComponent {
  // Sample recipe data
  recipes = [
    { id: 1, title: 'Spaghetti Marinara', image: 'https://www.closetcooking.com/wp-content/uploads/2015/11/MarinaraSauce8007571.jpg', usedIngredientCount: 5 },
    { id: 2, title: 'Hamburger', image: 'https://www.simplyrecipes.com/thmb/a9J_W4XytLfJi32wmEXIRS3vytE=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/__opt__aboutcom__coeus__resources__content_migration__simply_recipes__uploads__2018__06__HT-Grill-Burger-LEAD-VERTICAL-d0ae8c04f90c4cc2b03cd0b154e439eb.jpg', usedIngredientCount: 4 },
    // More recipes here
  ];

  // Method to handle the click on a recipe
  viewRecipe(recipeId: number) {
    console.log('Clicked recipe ID:', recipeId);
    // Add logic here to navigate for detailed recipe page or show more information
  }
}