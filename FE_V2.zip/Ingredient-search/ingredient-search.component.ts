import { Component } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field'; // MatFormField
import { MatChipsModule } from '@angular/material/chips'; // MatChipsModule
import { MatIconModule } from '@angular/material/icon'; // MatIconModule
import { MatButtonModule } from '@angular/material/button'; // MatButtonModule
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-ingredients-search',
  templateUrl: './ingredient-search.component.html',
  styleUrls: ['./ingredient-search.component.scss'],
  standalone: true,
  imports: [CommonModule, MatFormFieldModule, MatChipsModule,MatIconModule,MatButtonModule,ReactiveFormsModule]
})
export class IngredientSearchComponent {
  searchQuery: string = ''; // The search query entered by the user
  ingredients: string[] = ['Tomato', 'Onion', 'Garlic', 'Lettuce', 'Pepper', 'Chicken', 'Bacon']; // Sample list of ingredients
  filteredIngredients: string[] = []; // The list of ingredients filtered based on the search query

  constructor() {
    this.filteredIngredients = this.ingredients; // Initially show all ingredients
  }

  // Method to handle search query changes
  onSearch() {
    if (this.searchQuery.trim() === '') {
      this.filteredIngredients = this.ingredients; // Show all ingredients if search is empty
    } else {
      this.filteredIngredients = this.ingredients.filter(ingredient => 
        ingredient.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    }
  }
}