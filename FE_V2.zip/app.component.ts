import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { RecipeListComponent } from './Recipe-List/recipe-list.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field'; // MatFormField
import { MatChipsModule } from '@angular/material/chips'; // MatChipsModule
import { MatIconModule } from '@angular/material/icon'; // MatIconModule
import { MatButtonModule } from '@angular/material/button'; // MatButtonModule
import { IngredientSearchComponent } from './Ingredient-search/ingredient-search.component';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'TasteBuds';
}
