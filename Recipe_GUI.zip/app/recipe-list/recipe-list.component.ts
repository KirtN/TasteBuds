import { Component,Input } from '@angular/core';
import { Recipe } from '../models/models';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
@Component({
  selector: 'app-recipe-list',
  imports: [MatCardModule, MatListModule],
  templateUrl: './recipe-list.component.html',
  styleUrl: './recipe-list.component.scss'

})
export class RecipeListComponent {
  @Input() recipes: Recipe[] = [];
}
