import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';  // Import HomeComponent

// Define the routes
const routes: Routes = [
  { path: 'home', component: HomeComponent },  // Default route to HomeComponent
  // Add more routes here if needed
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],  // Import the RouterModule with routes
  exports: [RouterModule] 
})
export class AppRoutingModule {}