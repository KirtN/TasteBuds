import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';




@Component({
  selector: 'app-home',
  imports: [BrowserModule,
            CommonModule
  ],
  standalone: true,
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {

  recipes = [
    { title: 'Burger', image: 'assets/food1.jpg' },
    { title: 'Corndogs', image: 'assets/food2.jpg' },
    { title: 'Burrito', image: 'assets/food3.jpg' },
    { title: 'Mediterrenian', image: 'assets/food4.jpg' }
  ];
}
