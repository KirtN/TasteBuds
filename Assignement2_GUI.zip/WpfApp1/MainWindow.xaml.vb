﻿Imports System.IO

Class MainWindow

    Private Sub StartSimulationButton_Click(sender As Object, e As RoutedEventArgs)
        Dim filepath As String = FileInputTextBox.Text

        If Not File.Exists(filepath) Then
            MessageBox.Show("Wrong Text File!")
            Return

        End If
        Dim eventLog As New List(Of String)
        Dim summary As New StringWriter()

        'Run Sim here from program file
        Try
            'Dim simulation = New Program(filepath, eventLog)
            'simulation.Run_ProgramSim()

            'Summary- was trying to get this work
            'summary.WriteLine(simulation.GetSummary())
            summaryEvent.Text = summary.ToString()



        Catch ex As Exception
            MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error)

        End Try

    End Sub

    Private Sub ExportOutputButton_Click(sender As Object, e As RoutedEventArgs)
        Dim saveFileDialog As New Microsoft.Win32.SaveFileDialog()
        saveFileDialog.Filter = "Text File (*.txt)|*.txt|All Files (*.*)|*.*"
        saveFileDialog.Title = "Export Simulation Output"
        saveFileDialog.DefaultExt = "txt"

        If saveFileDialog.ShowDialog() = True Then

        End If
        Dim filePath As String = saveFileDialog.FileName

        Try
            Using writer As New StreamWriter(filePath)
                ' Write Event Log
                writer.WriteLine("Event Log:")
                For Each log As String In EventLog.ItemsSource
                    writer.WriteLine(log.ToString())
                Next

                ' Write Summary
                writer.WriteLine(Environment.NewLine & "Summary:")
                writer.WriteLine(summaryEvent.Text)
            End Using

            MessageBox.Show("Exported successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information)
        Catch ex As Exception
            MessageBox.Show($"An error occurred while exporting the file: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error)
        End Try
    End Sub
End Class
